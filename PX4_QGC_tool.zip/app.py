from __future__ import annotations

import json
import os
import queue
import socket
import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from serial.tools import list_ports

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure

from mavlink_client import (
    LogEntry,
    MavlinkClient,
    MavrosQgcBridge,
    ParamRecord,
    parse_qgc_params,
    save_qgc_params,
    update_qgc_param_value,
)
from ulog_tools import ULogModel


APP_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = APP_DIR / ".px4_flight_lab.json"

BG = "#f4f7fb"
CARD = "#ffffff"
TEXT = "#172033"
MUTED = "#667085"
BORDER = "#dfe5ee"
ACCENT = "#2563eb"
ACCENT_HOVER = "#1d4ed8"
SUCCESS = "#16a34a"
DANGER = "#dc2626"
HEADER = "#101828"
HEADER_MUTED = "#cbd5e1"


@dataclass(frozen=True)
class ConnectionProfile:
    key: str
    label: str
    endpoint: str
    baud: int
    kind: str
    hint: str


class PX4TestTool(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("PX4 Flight Lab")
        self.geometry("1320x820")
        self.minsize(1080, 690)
        self.configure(bg=BG)

        self.client = MavlinkClient()
        self.bridge = MavrosQgcBridge()
        self.ulog = ULogModel()
        self.ui_queue: queue.Queue = queue.Queue()
        self.log_entries: dict[str, LogEntry] = {}
        self.cancel_download = threading.Event()
        self.download_active = False
        self.logs_loading = False
        self.current_param_records = []
        self.param_file_paths: dict[str, Path] = {}
        self._param_signature: tuple = ()
        self._param_editor: ttk.Entry | None = None

        self.settings = self._load_settings()
        default_param_root = self._default_param_root()
        self.param_folder = tk.StringVar(value=self.settings.get("param_folder", str(default_param_root)))
        self.connection_profile = tk.StringVar()
        self.connection_profiles: dict[str, ConnectionProfile] = {}
        self.selected_profile_key = self.settings.get("connection_profile", "")
        self.connection_hint = tk.StringVar(value="")
        self.status = tk.StringVar(value="Desconectado")
        self.status_detail = tk.StringVar(value="Selecciona una conexión y pulsa Conectar")
        self.param_filter = tk.StringVar()
        self.param_filter.trace_add("write", lambda *_: self._render_param_preview())
        self.changed_only = tk.BooleanVar(value=True)
        self.param_library_info = tk.StringVar(value="")
        self.selected_param_info = tk.StringVar(value="")
        self.progress_text = tk.StringVar(value="Listo")
        self.logs_info = tk.StringVar(value=f"Destino: {APP_DIR / 'logs'}")
        self.ulog_path = tk.StringVar()
        self.ulog_info = tk.StringVar(value="Abre un .ulg para analizar el vuelo")
        self.quick_plot = tk.StringVar(value="Campo individual")

        (APP_DIR / "logs").mkdir(exist_ok=True)
        self._configure_styles()
        self._build_ui()
        self._refresh_connection_profiles()
        self.refresh_param_files(force=True)

        self.after(100, self._drain_ui_queue)
        self.after(3000, self._periodic_refresh)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------
    # Styling / shell
    # ------------------------------------------------------------------
    def _configure_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        base_font = ("DejaVu Sans", 10)
        style.configure(".", font=base_font, background=BG, foreground=TEXT)
        style.configure("App.TFrame", background=BG)
        style.configure("Card.TFrame", background=CARD, relief="flat")
        style.configure("Card.TLabel", background=CARD, foreground=TEXT)
        style.configure("Muted.TLabel", background=CARD, foreground=MUTED)
        style.configure("Section.TLabel", background=CARD, foreground=TEXT, font=("DejaVu Sans", 11, "bold"))
        style.configure("Primary.TButton", background=ACCENT, foreground="white", borderwidth=0, padding=(14, 9))
        style.map("Primary.TButton", background=[("active", ACCENT_HOVER), ("disabled", "#94a3b8")])
        style.configure("Secondary.TButton", background="#eef2f7", foreground=TEXT, borderwidth=0, padding=(12, 8))
        style.map("Secondary.TButton", background=[("active", "#e2e8f0")])
        style.configure("Danger.TButton", background="#fee2e2", foreground=DANGER, borderwidth=0, padding=(12, 8))
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", padding=(18, 10), background="#e8edf4", foreground=MUTED, borderwidth=0)
        style.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", TEXT)])
        style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=30, borderwidth=0)
        style.configure("Treeview.Heading", background="#eef2f7", foreground="#475467", relief="flat", padding=(8, 7))
        style.map("Treeview", background=[("selected", "#dbeafe")], foreground=[("selected", TEXT)])
        style.configure("TEntry", padding=6)
        style.configure("TCombobox", padding=5)
        style.configure("Horizontal.TProgressbar", troughcolor="#e5e7eb", background=ACCENT, borderwidth=0)

    def _build_ui(self) -> None:
        self._build_header()

        content = ttk.Frame(self, style="App.TFrame", padding=(18, 14, 18, 0))
        content.pack(fill=tk.BOTH, expand=True)

        self.notebook = ttk.Notebook(content)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
        self._build_params_tab()
        self._build_logs_tab()
        self._build_plot_tab()

        bottom = ttk.Frame(self, style="App.TFrame", padding=(18, 8, 18, 12))
        bottom.pack(fill=tk.X)
        self.progress = ttk.Progressbar(bottom, mode="determinate")
        self.progress.pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Label(bottom, textvariable=self.progress_text, background=BG, foreground=MUTED, width=42).pack(
            side=tk.LEFT, padx=(12, 0)
        )

    def _build_header(self) -> None:
        header = tk.Frame(self, bg=HEADER, padx=22, pady=16)
        header.pack(fill=tk.X)

        title_block = tk.Frame(header, bg=HEADER)
        title_block.pack(side=tk.LEFT, fill=tk.Y)
        tk.Label(
            title_block,
            text="PX4 Flight Lab",
            bg=HEADER,
            fg="white",
            font=("DejaVu Sans", 18, "bold"),
        ).pack(anchor="w")
        tk.Label(
            title_block,
            text="Parámetros, logs y análisis ULog en una sola herramienta",
            bg=HEADER,
            fg=HEADER_MUTED,
            font=("DejaVu Sans", 9),
        ).pack(anchor="w", pady=(2, 0))

        connection = tk.Frame(header, bg=HEADER)
        connection.pack(side=tk.RIGHT, fill=tk.X, expand=True, padx=(50, 0))
        top = tk.Frame(connection, bg=HEADER)
        top.pack(fill=tk.X)

        tk.Label(top, text="Conexión", bg=HEADER, fg=HEADER_MUTED, font=("DejaVu Sans", 9)).pack(side=tk.LEFT)
        self.connection_combo = ttk.Combobox(
            top,
            textvariable=self.connection_profile,
            state="readonly",
            width=38,
        )
        self.connection_combo.pack(side=tk.LEFT, padx=(8, 10))
        self.connection_combo.bind("<<ComboboxSelected>>", lambda _: self._connection_profile_changed())
        self.connection_combo.bind("<Button-1>", lambda _: self._refresh_connection_profiles())

        self.connect_btn = ttk.Button(top, text="Conectar", style="Primary.TButton", command=self._toggle_connection)
        self.connect_btn.pack(side=tk.LEFT)

        self.status_dot = tk.Label(top, text="●", bg=HEADER, fg="#94a3b8", font=("DejaVu Sans", 12))
        self.status_dot.pack(side=tk.LEFT, padx=(16, 5))
        tk.Label(top, textvariable=self.status, bg=HEADER, fg="white", font=("DejaVu Sans", 10)).pack(side=tk.LEFT)

        tk.Label(
            connection,
            textvariable=self.connection_hint,
            bg=HEADER,
            fg=HEADER_MUTED,
            font=("DejaVu Sans", 8),
            justify=tk.LEFT,
            anchor="w",
            wraplength=760,
        ).pack(fill=tk.X, pady=(7, 0))

    @staticmethod
    def _card(parent, padding=(14, 12)):
        return ttk.Frame(parent, style="Card.TFrame", padding=padding)

    # ------------------------------------------------------------------
    # Connection profiles
    # ------------------------------------------------------------------
    def _refresh_connection_profiles(self) -> None:
        previous_key = self._current_profile().key if self._current_profile() else self.selected_profile_key
        profiles: list[ConnectionProfile] = []

        try:
            ports = sorted(list_ports.comports(), key=lambda p: p.device)
        except Exception:
            ports = []

        acm_ports = [p for p in ports if p.device.startswith("/dev/ttyACM")]
        usb_ports = [p for p in ports if p.device.startswith("/dev/ttyUSB")]

        for port in acm_ports:
            desc = (port.description or "").strip()
            extra = f" · {desc}" if desc and desc != "n/a" else ""
            profiles.append(
                ConnectionProfile(
                    key=f"usb:{port.device}",
                    label=f"USB · {port.device}{extra}",
                    endpoint=f"serial:{port.device}:115200",
                    baud=115200,
                    kind="usb",
                    hint="Conexión USB directa. Si QGroundControl tiene abierta esa Pixhawk por USB, desconéctalo antes.",
                )
            )

        if not acm_ports:
            profiles.append(
                ConnectionProfile(
                    key="usb:/dev/ttyACM0",
                    label="USB · /dev/ttyACM0",
                    endpoint="serial:/dev/ttyACM0:115200",
                    baud=115200,
                    kind="usb",
                    hint="Perfil USB habitual. La aplicación detectará automáticamente /dev/ttyACM* cuando aparezca.",
                )
            )

        for port in usb_ports:
            desc = (port.description or "").strip()
            extra = f" · {desc}" if desc and desc != "n/a" else ""
            profiles.append(
                ConnectionProfile(
                    key=f"radio:{port.device}",
                    label=f"Radio · {port.device}{extra}",
                    endpoint=f"serial:{port.device}:57600",
                    baud=57600,
                    kind="radio",
                    hint="Radio directa a 57600. MAVROS y el AutoConnect SiK de QGC no deben usar simultáneamente ese /dev/ttyUSB*.",
                )
            )

        if not usb_ports:
            profiles.append(
                ConnectionProfile(
                    key="radio:/dev/ttyUSB0",
                    label="Radio · /dev/ttyUSB0",
                    endpoint="serial:/dev/ttyUSB0:57600",
                    baud=57600,
                    kind="radio",
                    hint="Perfil de radio habitual. SiK/MAVROS deben dejar libre /dev/ttyUSB0 para conexión directa.",
                )
            )

        profiles.extend(
            [
                ConnectionProfile(
                    key="mavros:solo",
                    label="MAVROS UDP · herramienta sola",
                    endpoint="udpin:127.0.0.1:14550",
                    baud=0,
                    kind="mavros_solo",
                    hint="Compatible con gcs_url:=udp://@127.0.0.1:14550. QGroundControl debe tener libre el UDP 14550.",
                ),
                ConnectionProfile(
                    key="mavros:shared",
                    label="MAVROS + QGroundControl · compartido",
                    endpoint="udpin:127.0.0.1:14552",
                    baud=0,
                    kind="mavros_shared",
                    hint=(
                        "Modo recomendado si QGC está abierto. Inicia MAVROS con "
                        "gcs_url:=udp://@127.0.0.1:14551; la herramienta puentea MAVROS hacia QGC:14550 y usa 14552 internamente."
                    ),
                ),
                ConnectionProfile(
                    key="udp:14551",
                    label="UDP dedicado · puerto 14551",
                    endpoint="udpin:0.0.0.0:14551",
                    baud=0,
                    kind="udp",
                    hint="Para un router MAVLink externo que envíe una copia bidireccional de MAVLink al puerto 14551.",
                ),
            ]
        )

        self.connection_profiles = {p.label: p for p in profiles}
        labels = [p.label for p in profiles]
        self.connection_combo["values"] = labels

        selected = next((p for p in profiles if p.key == previous_key), None)
        if selected is None:
            selected = next((p for p in profiles if p.key == self.selected_profile_key), None)
        if selected is None:
            selected = next((p for p in profiles if p.kind == "usb" and Path(p.endpoint.split(":")[1]).exists()), None)
        if selected is None:
            selected = profiles[0]
        self.connection_profile.set(selected.label)
        self.selected_profile_key = selected.key
        self._connection_profile_changed()

    def _current_profile(self) -> ConnectionProfile | None:
        return self.connection_profiles.get(self.connection_profile.get())

    def _connection_profile_changed(self) -> None:
        profile = self._current_profile()
        if profile is None:
            return
        self.selected_profile_key = profile.key
        self.connection_hint.set(profile.hint)

    @staticmethod
    def _udp_port_available(port: int) -> bool:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False
        finally:
            sock.close()

    def _toggle_connection(self) -> None:
        if self.client.connected:
            self.disconnect()
        else:
            self.connect()

    def connect(self) -> None:
        profile = self._current_profile()
        if profile is None:
            return
        self.status.set("Conectando…")
        self.status_detail.set(profile.label)
        self.status_dot.configure(fg="#f59e0b")
        self.connect_btn.configure(state="disabled")
        self.connection_combo.configure(state="disabled")

        def task():
            if profile.kind == "mavros_solo" and not self._udp_port_available(14550):
                raise RuntimeError(
                    "El UDP 14550 ya está ocupado, normalmente por QGroundControl. "
                    "Usa 'MAVROS + QGroundControl · compartido' o cierra/desconecta el UDP de QGC."
                )
            if profile.kind == "mavros_shared":
                self.bridge.start()
            try:
                return self.client.connect(profile.endpoint, baud=profile.baud or 115200, timeout=11.0)
            except Exception:
                if profile.kind == "mavros_shared":
                    self.bridge.stop()
                raise

        def ok(ids):
            self.status.set("Conectado")
            self.status_detail.set(f"PX4 sys={ids[0]} · comp={ids[1]} · {profile.label}")
            self.status_dot.configure(fg=SUCCESS)
            self.connect_btn.configure(text="Desconectar", state="normal", style="Secondary.TButton")
            self.progress_text.set(f"Conectado a sistema {ids[0]}")

        def err(exc):
            self.status.set("Desconectado")
            self.status_detail.set("No hay enlace MAVLink activo")
            self.status_dot.configure(fg="#94a3b8")
            self.connect_btn.configure(text="Conectar", state="normal", style="Primary.TButton")
            self.connection_combo.configure(state="readonly")
            extra = ""
            if profile.kind == "mavros_shared":
                extra = (
                    "\n\nPara este modo inicia MAVROS así:\n"
                    "ros2 launch mavros px4.launch fcu_url:=/dev/ttyUSB0:57600 "
                    "gcs_url:=udp://@127.0.0.1:14551"
                )
            messagebox.showerror("Conexión MAVLink", f"{exc}{extra}")

        self._async(task, ok, err)

    def disconnect(self) -> None:
        self.cancel_download.set()
        self.client.close()
        self.bridge.stop()
        self.status.set("Desconectado")
        self.status_detail.set("Selecciona una conexión y pulsa Conectar")
        self.status_dot.configure(fg="#94a3b8")
        self.connect_btn.configure(text="Conectar", state="normal", style="Primary.TButton")
        self.connection_combo.configure(state="readonly")
        self.progress_text.set("Desconectado")

    # ------------------------------------------------------------------
    # Parameters
    # ------------------------------------------------------------------
    def _build_params_tab(self) -> None:
        tab = ttk.Frame(self.notebook, style="App.TFrame", padding=12)
        self.notebook.add(tab, text="Parámetros")

        library = self._card(tab)
        library.pack(fill=tk.X, pady=(0, 10))
        top = ttk.Frame(library, style="Card.TFrame")
        top.pack(fill=tk.X)
        ttk.Label(top, text="Biblioteca de configuraciones", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(top, text="Elegir carpeta", style="Secondary.TButton", command=self.choose_param_folder).pack(side=tk.RIGHT)

        ttk.Label(library, textvariable=self.param_folder, style="Muted.TLabel").pack(anchor="w", pady=(5, 2))
        ttk.Label(library, textvariable=self.param_library_info, style="Muted.TLabel").pack(anchor="w")

        body = ttk.Panedwindow(tab, orient=tk.HORIZONTAL)
        body.pack(fill=tk.BOTH, expand=True)

        left_card = self._card(body, padding=10)
        right_card = self._card(body, padding=10)
        body.add(left_card, weight=1)
        body.add(right_card, weight=3)

        ttk.Label(left_card, text="Archivos .params", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        self.param_files_tree = ttk.Treeview(left_card, columns=("file",), show="headings", selectmode="browse")
        self.param_files_tree.heading("file", text="Configuración")
        self.param_files_tree.column("file", width=280, anchor=tk.W)
        self.param_files_tree.pack(fill=tk.BOTH, expand=True)
        self.param_files_tree.bind("<<TreeviewSelect>>", lambda _: self.preview_param_file())

        right_top = ttk.Frame(right_card, style="Card.TFrame")
        right_top.pack(fill=tk.X)
        ttk.Label(right_top, text="Vista previa", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Entry(right_top, textvariable=self.param_filter, width=28).pack(side=tk.RIGHT)
        ttk.Label(right_top, text="Buscar", style="Muted.TLabel").pack(side=tk.RIGHT, padx=(0, 6))

        ttk.Label(right_card, textvariable=self.selected_param_info, style="Muted.TLabel").pack(anchor="w", pady=(5, 6))
        cols = ("name", "value", "type", "component")
        self.param_tree = ttk.Treeview(right_card, columns=cols, show="headings")
        for col, title, width in [
            ("name", "Parámetro", 260),
            ("value", "Valor", 210),
            ("type", "Tipo", 90),
            ("component", "Comp.", 70),
        ]:
            self.param_tree.heading(col, text=title)
            self.param_tree.column(col, width=width, anchor=tk.W)
        self.param_tree.pack(fill=tk.BOTH, expand=True)
        self.param_tree.bind("<Double-1>", self._begin_param_value_edit)
        self.param_tree.bind("<Return>", self._begin_param_value_edit_from_selection)

        actions = ttk.Frame(tab, style="App.TFrame", padding=(0, 10, 0, 0))
        actions.pack(fill=tk.X)
        ttk.Checkbutton(actions, text="Aplicar solo cambios", variable=self.changed_only).pack(side=tk.LEFT)
        ttk.Button(actions, text="Guardar backup", style="Secondary.TButton", command=self.backup_params).pack(side=tk.RIGHT)
        ttk.Button(actions, text="Comparar", style="Secondary.TButton", command=self.compare_params).pack(side=tk.RIGHT, padx=6)
        ttk.Button(actions, text="Aplicar al vehículo", style="Primary.TButton", command=self.apply_params).pack(side=tk.RIGHT)
        ttk.Button(
            actions,
            text="Descargar parámetros actuales",
            style="Secondary.TButton",
            command=self.download_current_params,
        ).pack(side=tk.RIGHT, padx=(0, 6))

    def _default_param_root(self) -> Path:
        candidates = [APP_DIR / "params", APP_DIR / "parametros", APP_DIR / "parameter_sets", APP_DIR]
        for path in candidates:
            if path.exists() and any(self._iter_param_files(path)):
                return path
        return APP_DIR

    @staticmethod
    def _iter_param_files(root: Path):
        if not root.exists() or not root.is_dir():
            return
        ignored = {".venv", ".runtime", "__pycache__", ".git", "backups", "logs"}
        for current, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d not in ignored and not d.startswith(".")]
            current_path = Path(current)
            for name in files:
                if name.lower().endswith(".params"):
                    yield current_path / name

    def choose_param_folder(self) -> None:
        folder = filedialog.askdirectory(initialdir=self.param_folder.get() or str(APP_DIR))
        if folder:
            self.param_folder.set(folder)
            self.refresh_param_files(force=True)

    def refresh_param_files(self, force: bool = False) -> None:
        root = Path(self.param_folder.get()).expanduser()
        if not root.exists():
            self.param_library_info.set("La carpeta seleccionada no existe")
            return

        files = sorted(self._iter_param_files(root), key=lambda p: str(p).lower())
        signature = tuple((str(p), p.stat().st_mtime_ns, p.stat().st_size) for p in files)
        if not force and signature == self._param_signature:
            return
        self._param_signature = signature

        selected_path = None
        selection = self.param_files_tree.selection() if hasattr(self, "param_files_tree") else ()
        if selection:
            selected_path = self.param_file_paths.get(selection[0])

        for item in self.param_files_tree.get_children():
            self.param_files_tree.delete(item)
        self.param_file_paths.clear()

        for idx, path in enumerate(files):
            rel = path.relative_to(root) if path.is_relative_to(root) else path
            iid = f"p{idx}"
            self.param_file_paths[iid] = path
            self.param_files_tree.insert("", tk.END, iid=iid, values=(str(rel),))

        self.param_library_info.set(
            f"{len(files)} archivo{'s' if len(files) != 1 else ''} detectado{'s' if len(files) != 1 else ''} · búsqueda recursiva"
        )
        if files:
            target_iid = next((iid for iid, p in self.param_file_paths.items() if p == selected_path), "p0")
            self.param_files_tree.selection_set(target_iid)
            self.param_files_tree.focus(target_iid)
            self.preview_param_file()
        else:
            self.current_param_records = []
            self.selected_param_info.set("No se encontraron .params en esta carpeta ni en sus subcarpetas")
            self._render_param_preview()

    def _selected_param_path(self) -> Path:
        sel = self.param_files_tree.selection()
        if not sel or sel[0] not in self.param_file_paths:
            raise ValueError("Selecciona un archivo .params.")
        return self.param_file_paths[sel[0]]

    def preview_param_file(self) -> None:
        try:
            path = self._selected_param_path()
            self.current_param_records = parse_qgc_params(path)
        except Exception as exc:
            self.current_param_records = []
            self.selected_param_info.set(str(exc))
            self._render_param_preview()
            return
        self.selected_param_info.set(f"{path.name} · {len(self.current_param_records)} parámetros")
        self._render_param_preview()

    def _render_param_preview(self) -> None:
        if not hasattr(self, "param_tree"):
            return
        for item in self.param_tree.get_children():
            self.param_tree.delete(item)
        needle = self.param_filter.get().strip().upper()
        shown = 0
        for idx, rec in enumerate(self.current_param_records):
            if needle and needle not in rec.name.upper():
                continue
            typ = "INT32" if rec.mav_type == 6 else "REAL32" if rec.mav_type == 9 else str(rec.mav_type)
            self.param_tree.insert(
                "",
                tk.END,
                iid=f"param:{idx}",
                values=(rec.name, rec.value, typ, rec.component_id),
            )
            shown += 1
        if needle and self.current_param_records:
            self.progress_text.set(f"{shown} parámetros coinciden con el filtro")

    def _begin_param_value_edit_from_selection(self, _event=None) -> str:
        selection = self.param_tree.selection()
        if not selection:
            return "break"
        iid = selection[0]
        if not iid.startswith("param:"):
            return "break"
        bbox = self.param_tree.bbox(iid, "value")
        if not bbox:
            return "break"
        self._open_param_value_editor(iid, bbox)
        return "break"

    def _begin_param_value_edit(self, event) -> str | None:
        if self.param_tree.identify_region(event.x, event.y) != "cell":
            return None
        if self.param_tree.identify_column(event.x) != "#2":
            return None
        iid = self.param_tree.identify_row(event.y)
        if not iid.startswith("param:"):
            return None
        bbox = self.param_tree.bbox(iid, "value")
        if not bbox:
            return None
        self.param_tree.selection_set(iid)
        self.param_tree.focus(iid)
        self._open_param_value_editor(iid, bbox)
        return "break"

    def _open_param_value_editor(self, iid: str, bbox) -> None:
        try:
            index = int(iid.split(":", 1)[1])
            rec = self.current_param_records[index]
        except (ValueError, IndexError):
            return

        if self._param_editor is not None:
            try:
                self._param_editor.destroy()
            except tk.TclError:
                pass

        x, y, width, height = bbox
        editor = ttk.Entry(self.param_tree)
        self._param_editor = editor
        editor.insert(0, str(rec.value))
        editor.select_range(0, tk.END)
        editor.place(x=x, y=y, width=width, height=height)
        editor.focus_set()

        closed = False
        committing = False

        def close_editor() -> None:
            nonlocal closed
            if self._param_editor is editor:
                self._param_editor = None
            try:
                editor.destroy()
            except tk.TclError:
                pass
            closed = True

        def cancel(_event=None):
            if not closed:
                close_editor()
            self.param_tree.focus_set()
            return "break"

        def commit(_event=None):
            nonlocal committing
            if closed or committing:
                return "break"
            committing = True
            text = editor.get().strip()
            try:
                if rec.mav_type == 6:
                    numeric = float(text)
                    if not numeric.is_integer():
                        raise ValueError("Los parámetros INT32 deben tener un valor entero.")
                    value: float | int = int(numeric)
                else:
                    value = float(text)
                updated = ParamRecord(
                    vehicle_id=rec.vehicle_id,
                    component_id=rec.component_id,
                    name=rec.name,
                    value=value,
                    mav_type=rec.mav_type,
                )
                path = self._selected_param_path()
                update_qgc_param_value(path, updated)
                self.current_param_records[index] = updated
            except Exception as exc:
                messagebox.showerror("Parámetros", str(exc))
                committing = False
                if not closed:
                    editor.focus_set()
                    editor.select_range(0, tk.END)
                return "break"

            close_editor()
            self.param_tree.set(iid, "value", value)
            self.selected_param_info.set(f"{path.name} · {len(self.current_param_records)} parámetros")
            self.progress_text.set(f"{rec.name} actualizado en {path.name}")
            # Keep the file signature in sync so the periodic refresh does not redraw
            # the table immediately after an inline edit.
            root = Path(self.param_folder.get()).expanduser()
            files = sorted(self._iter_param_files(root), key=lambda p: str(p).lower()) if root.exists() else []
            self._param_signature = tuple((str(p), p.stat().st_mtime_ns, p.stat().st_size) for p in files)
            self.param_tree.focus_set()
            return "break"

        editor.bind("<Return>", commit)
        editor.bind("<KP_Enter>", commit)
        editor.bind("<Escape>", cancel)
        editor.bind("<FocusOut>", commit)

    def download_current_params(self) -> None:
        """Download the vehicle's current parameters to a user-selected .params file."""
        if not self.client.connected:
            messagebox.showinfo("Parámetros actuales", "Conecta primero con la Pixhawk.")
            return

        root = Path(self.param_folder.get()).expanduser()
        initial_dir = root if root.exists() and root.is_dir() else APP_DIR
        default_name = f"parametros_actuales_{datetime.now().strftime('%Y%m%d_%H%M%S')}.params"
        filename = filedialog.asksaveasfilename(
            title="Guardar parámetros actuales",
            initialdir=str(initial_dir),
            initialfile=default_name,
            defaultextension=".params",
            filetypes=[("Parámetros QGroundControl", "*.params"), ("Todos los archivos", "*.*")],
        )
        if not filename:
            return

        path = Path(filename)

        def task():
            params = self.client.request_all_params(
                timeout=32.0 if self.client.transport == "radio" else 24.0,
                progress=lambda a, b: self._progress(a, b, "Descargando parámetros actuales…"),
            )
            save_qgc_params(path, params.values())
            return path, len(params)

        def ok(payload):
            saved, count = payload
            self._reset_progress(f"Parámetros actuales guardados: {saved.name}")
            self.refresh_param_files(force=True)
            messagebox.showinfo(
                "Parámetros actuales",
                f"Se han descargado {count} parámetros actuales de la Pixhawk.\n\nGuardado en:\n{saved}",
            )

        def err(exc):
            self._reset_progress("No se pudieron descargar los parámetros actuales")
            messagebox.showerror("Parámetros actuales", str(exc))

        self._async(task, ok, err)

    def backup_params(self) -> None:
        if not self.client.connected:
            messagebox.showinfo("Backup", "Conecta primero con la Pixhawk.")
            return
        folder = Path(self.param_folder.get()) / "backups"
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.params"

        def task():
            params = self.client.request_all_params(
                timeout=32.0 if self.client.transport == "radio" else 24.0,
                progress=lambda a, b: self._progress(a, b, "Leyendo parámetros…"),
            )
            save_qgc_params(path, params.values())
            return path

        def ok(saved):
            self._reset_progress(f"Backup guardado: {saved.name}")
            self.refresh_param_files(force=True)
            messagebox.showinfo("Backup", f"Guardado en:\n{saved}")

        self._async(task, ok)

    def compare_params(self) -> None:
        if not self.client.connected:
            messagebox.showinfo("Comparación", "Conecta primero con la Pixhawk.")
            return
        try:
            path = self._selected_param_path()
            target = parse_qgc_params(path)
        except Exception as exc:
            messagebox.showerror("Comparación", str(exc))
            return

        def task():
            current = self.client.request_all_params(
                timeout=32.0 if self.client.transport == "radio" else 24.0,
                progress=lambda a, b: self._progress(a, b, "Comparando con el vehículo…"),
            )
            diffs = []
            for rec in target:
                old = current.get((rec.component_id, rec.name))
                if old is None:
                    diffs.append((rec.name, "NO EXISTE", rec.value, rec.mav_type, rec.component_id))
                elif not self.client._same_value(old.value, rec.value, rec.mav_type):
                    diffs.append((rec.name, old.value, rec.value, rec.mav_type, rec.component_id))
            return diffs

        def ok(diffs):
            for item in self.param_tree.get_children():
                self.param_tree.delete(item)
            for name, old, new, typ, comp in diffs:
                typ_text = "INT32" if typ == 6 else "REAL32" if typ == 9 else str(typ)
                self.param_tree.insert("", tk.END, values=(name, f"{old}  →  {new}", typ_text, comp))
            self._reset_progress(f"{len(diffs)} diferencias encontradas")
            if not diffs:
                messagebox.showinfo("Comparación", "El archivo coincide con los parámetros recibidos.")

        self._async(task, ok)

    def apply_params(self) -> None:
        if not self.client.connected:
            messagebox.showinfo("Parámetros", "Conecta primero con la Pixhawk.")
            return
        try:
            path = self._selected_param_path()
        except Exception as exc:
            messagebox.showerror("Parámetros", str(exc))
            return

        if not messagebox.askyesno(
            "Aplicar parámetros",
            f"Se aplicará {path.name}.\n\nLa herramienta creará un backup automático antes de escribir. "
            "El vehículo debe estar desarmado.\n\n¿Continuar?",
        ):
            return

        def task():
            backup_dir = Path(self.param_folder.get()) / "backups"
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup_path = backup_dir / f"auto_before_{path.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.params"
            current = self.client.request_all_params(
                timeout=32.0 if self.client.transport == "radio" else 24.0,
                progress=lambda a, b: self._progress(a, b, "Creando backup…"),
            )
            save_qgc_params(backup_path, current.values())
            results = self.client.apply_param_file(
                path,
                changed_only=self.changed_only.get(),
                progress=lambda a, b, n: self._progress(a, b, f"Escribiendo {n}"),
            )
            return backup_path, results

        def ok(payload):
            backup, results = payload
            failures = [(r, why) for r, good, why in results if not good]
            self.refresh_param_files(force=True)
            self._reset_progress(f"Carga terminada · {len(results) - len(failures)}/{len(results)} correctos")
            if failures:
                txt = "\n".join(f"{r.name}: {why}" for r, why in failures[:12])
                messagebox.showwarning(
                    "Carga terminada con avisos",
                    f"Backup: {backup.name}\nIntentados: {len(results)}\nFallos: {len(failures)}\n\n{txt}",
                )
            else:
                messagebox.showinfo(
                    "Carga terminada",
                    f"Backup automático: {backup.name}\nParámetros modificados: {len(results)}",
                )

        self._async(task, ok)

    # ------------------------------------------------------------------
    # Logs
    # ------------------------------------------------------------------
    def _build_logs_tab(self) -> None:
        tab = ttk.Frame(self.notebook, style="App.TFrame", padding=12)
        self.notebook.add(tab, text="Logs Pixhawk")

        header = self._card(tab)
        header.pack(fill=tk.X, pady=(0, 10))
        row = ttk.Frame(header, style="Card.TFrame")
        row.pack(fill=tk.X)
        ttk.Label(row, text="Logs almacenados en la Pixhawk", style="Section.TLabel").pack(side=tk.LEFT)
        self.logs_sync_btn = ttk.Button(row, text="Sincronizar", style="Secondary.TButton", command=self.refresh_logs)
        self.logs_sync_btn.pack(side=tk.RIGHT)
        ttk.Label(header, textvariable=self.logs_info, style="Muted.TLabel").pack(anchor="w", pady=(5, 0))

        card = self._card(tab, padding=8)
        card.pack(fill=tk.BOTH, expand=True)
        cols = ("id", "date", "size")
        self.logs_tree = ttk.Treeview(card, columns=cols, show="headings", selectmode="browse")
        self.logs_tree.heading("id", text="ID")
        self.logs_tree.heading("date", text="Fecha UTC")
        self.logs_tree.heading("size", text="Tamaño")
        self.logs_tree.column("id", width=80, anchor=tk.CENTER)
        self.logs_tree.column("date", width=300)
        self.logs_tree.column("size", width=150, anchor=tk.E)
        self.logs_tree.pack(fill=tk.BOTH, expand=True)
        self.logs_tree.bind("<Double-1>", lambda _: self.download_selected_log())

        actions = ttk.Frame(tab, style="App.TFrame", padding=(0, 10, 0, 0))
        actions.pack(fill=tk.X)
        ttk.Label(
            actions,
            text="Doble clic sobre un log también inicia la descarga.",
            background=BG,
            foreground=MUTED,
        ).pack(side=tk.LEFT)
        self.download_btn = ttk.Button(
            actions,
            text="Descargar seleccionado",
            style="Primary.TButton",
            command=self.download_selected_log,
        )
        self.download_btn.pack(side=tk.RIGHT)

    def refresh_logs(self) -> None:
        if not self.client.connected:
            messagebox.showinfo("Logs", "Conecta primero con la Pixhawk.")
            return
        if self.logs_loading:
            return
        self.logs_loading = True
        self.logs_sync_btn.configure(state="disabled")
        self.progress_text.set("Solicitando lista de logs…")

        def ok(entries):
            self.logs_loading = False
            self.logs_sync_btn.configure(state="normal")
            self.log_entries.clear()
            for item in self.logs_tree.get_children():
                self.logs_tree.delete(item)
            for e in entries:
                iid = str(e.log_id)
                self.log_entries[iid] = e
                size = self._format_size(e.size)
                self.logs_tree.insert("", tk.END, iid=iid, values=(e.log_id, e.date_text, size))
            if entries:
                first = str(entries[0].log_id)
                self.logs_tree.selection_set(first)
                self.logs_tree.focus(first)
            self.logs_info.set(f"{len(entries)} logs encontrados · destino: {APP_DIR / 'logs'}")
            self._reset_progress(f"{len(entries)} logs disponibles")

        def err(exc):
            self.logs_loading = False
            self.logs_sync_btn.configure(state="normal")
            self._reset_progress("No se pudo leer la lista de logs")
            messagebox.showerror("Logs", str(exc))

        self._async(lambda: self.client.list_logs(timeout=14.0 if self.client.transport == "radio" else 10.0), ok, err)

    @staticmethod
    def _format_size(size: int) -> str:
        if size < 1024 * 1024:
            return f"{size / 1024:.1f} KiB"
        return f"{size / 1024 / 1024:.2f} MiB"

    def download_selected_log(self) -> None:
        if self.download_active:
            self.cancel_download.set()
            self.progress_text.set("Cancelando descarga…")
            return
        if not self.client.connected:
            messagebox.showinfo("Logs", "Conecta primero con la Pixhawk.")
            return
        selection = self.logs_tree.selection()
        if not selection:
            messagebox.showinfo("Logs", "Selecciona un log.")
            return
        entry = self.log_entries[selection[0]]
        folder = APP_DIR / "logs"
        folder.mkdir(parents=True, exist_ok=True)
        stamp = (
            datetime.fromtimestamp(entry.time_utc, tz=timezone.utc).strftime("%Y-%m-%d_%H-%M-%S")
            if entry.time_utc
            else "sin_fecha"
        )
        dest = folder / f"log_{entry.log_id}_{stamp}.ulg"
        self.cancel_download.clear()
        self.download_active = True
        self.download_btn.configure(text="Cancelar descarga", style="Danger.TButton")

        def task():
            return self.client.download_log(
                entry,
                dest,
                progress=lambda a, b: self._progress(
                    a,
                    b,
                    f"Log {entry.log_id} · {100 * a / max(1, b):.0f}% · {self._format_size(a)} / {self._format_size(b)}",
                ),
                cancel_event=self.cancel_download,
            )

        def finish_button():
            self.download_active = False
            self.download_btn.configure(text="Descargar seleccionado", style="Primary.TButton")

        def ok(path):
            finish_button()
            self._reset_progress(f"Descargado: {path.name}")
            self._load_ulog_path(path, show_errors=False)
            self.notebook.select(2)

        def err(exc):
            finish_button()
            self._reset_progress("Descarga interrumpida")
            messagebox.showerror("Descarga de log", str(exc))

        self._async(task, ok, err)

    # ------------------------------------------------------------------
    # ULog analyzer
    # ------------------------------------------------------------------
    def _build_plot_tab(self) -> None:
        tab = ttk.Frame(self.notebook, style="App.TFrame", padding=12)
        self.notebook.add(tab, text="Analizador ULog")

        header = self._card(tab)
        header.pack(fill=tk.X, pady=(0, 10))
        row = ttk.Frame(header, style="Card.TFrame")
        row.pack(fill=tk.X)
        ttk.Label(row, text="Análisis del vuelo", style="Section.TLabel").pack(side=tk.LEFT)
        ttk.Button(row, text="Abrir .ulg", style="Secondary.TButton", command=self.open_ulog).pack(side=tk.RIGHT)
        ttk.Button(row, text="Exportar topic CSV", style="Secondary.TButton", command=self.export_topic_csv).pack(
            side=tk.RIGHT, padx=(0, 6)
        )
        ttk.Label(header, textvariable=self.ulog_path, style="Muted.TLabel").pack(anchor="w", pady=(5, 1))
        ttk.Label(header, textvariable=self.ulog_info, style="Muted.TLabel").pack(anchor="w")

        body = ttk.Panedwindow(tab, orient=tk.HORIZONTAL)
        body.pack(fill=tk.BOTH, expand=True)
        selectors = self._card(body, padding=10)
        plot_frame = self._card(body, padding=8)
        body.add(selectors, weight=1)
        body.add(plot_frame, weight=4)

        ttk.Label(selectors, text="Vista rápida", style="Section.TLabel").pack(anchor=tk.W)
        quick = ttk.Combobox(
            selectors,
            textvariable=self.quick_plot,
            state="readonly",
            values=(
                "Campo individual",
                "Actitud",
                "Velocidad angular",
                "Posición local",
                "Velocidad local",
                "Batería",
                "Comunicación",
            ),
        )
        quick.pack(fill=tk.X, pady=(5, 14))
        quick.bind("<<ComboboxSelected>>", lambda _: self._quick_plot_changed())

        ttk.Label(selectors, text="Topic / instancia", style="Section.TLabel").pack(anchor=tk.W)
        self.topic_combo = ttk.Combobox(selectors, state="readonly")
        self.topic_combo.pack(fill=tk.X, pady=(5, 12))
        self.topic_combo.bind("<<ComboboxSelected>>", lambda _: self.topic_changed())

        ttk.Label(selectors, text="Campo", style="Section.TLabel").pack(anchor=tk.W)
        self.field_list = tk.Listbox(
            selectors,
            exportselection=False,
            borderwidth=0,
            highlightthickness=1,
            highlightbackground=BORDER,
            selectbackground="#dbeafe",
            selectforeground=TEXT,
            bg=CARD,
            fg=TEXT,
        )
        self.field_list.pack(fill=tk.BOTH, expand=True, pady=(5, 8))
        self.field_list.bind("<Double-1>", lambda _: self.plot_selected_field())
        ttk.Button(selectors, text="Graficar campo", style="Primary.TButton", command=self.plot_selected_field).pack(fill=tk.X)

        self.figure = Figure(figsize=(8, 5.5), dpi=100, facecolor=CARD)
        self.ax = self.figure.add_subplot(111)
        self._style_axes()
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.draw()
        toolbar_plot = NavigationToolbar2Tk(self.canvas, plot_frame, pack_toolbar=False)
        toolbar_plot.update()
        toolbar_plot.pack(fill=tk.X)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def _style_axes(self) -> None:
        self.ax.set_facecolor(CARD)
        self.ax.set_xlabel("Tiempo [s]")
        self.ax.grid(True, alpha=0.2)
        for spine in self.ax.spines.values():
            spine.set_alpha(0.25)

    def open_ulog(self) -> None:
        path = filedialog.askopenfilename(
            initialdir=str(APP_DIR / "logs"),
            filetypes=[("PX4 ULog", "*.ulg"), ("Todos", "*.*")],
        )
        if path:
            self._load_ulog_path(Path(path))

    def _load_ulog_path(self, path: Path, show_errors: bool = True) -> None:
        try:
            self.ulog.load(path)
        except Exception as exc:
            if show_errors:
                messagebox.showerror("ULog", str(exc))
            return
        self.ulog_path.set(str(path))
        topics = self.ulog.topics()
        self.topic_combo["values"] = topics
        if topics:
            self.topic_combo.current(0)
            self.topic_changed()
        summary = self.ulog.summary()
        self.ulog_info.set(
            f"PX4 {summary.get('version') or 'n/d'} · {summary.get('duration_s', 0):.1f} s · "
            f"{summary.get('topics', 0)} topics · {summary.get('dropouts', 0)} dropouts"
        )
        self.quick_plot.set("Campo individual")

    def topic_changed(self) -> None:
        topic = self.topic_combo.get()
        self.field_list.delete(0, tk.END)
        if not topic:
            return
        for field in self.ulog.fields(topic):
            self.field_list.insert(tk.END, field)
        if self.field_list.size():
            self.field_list.selection_set(0)

    def plot_selected_field(self) -> None:
        topic = self.topic_combo.get()
        sel = self.field_list.curselection()
        if not topic or not sel:
            return
        field = self.field_list.get(sel[0])
        try:
            t, y = self.ulog.series(topic, field)
            self.ax.clear()
            self.ax.plot(t, y, linewidth=1.15)
            self.ax.set_title(f"{topic} · {field}")
            self.ax.set_xlabel("Tiempo desde inicio del topic [s]")
            self.ax.set_ylabel(field)
            self._style_axes()
            self.figure.tight_layout()
            self.canvas.draw_idle()
            self.quick_plot.set("Campo individual")
        except Exception as exc:
            messagebox.showerror("Gráfica", str(exc))

    def _quick_plot_changed(self) -> None:
        preset = self.quick_plot.get()
        if preset == "Campo individual":
            return
        if self.ulog.ulog is None:
            messagebox.showinfo("Analizador", "Abre primero un archivo .ulg.")
            self.quick_plot.set("Campo individual")
            return
        try:
            title, ylabel, series = self.ulog.quick_plot(preset)
            self.ax.clear()
            for label, t, y in series:
                self.ax.plot(t, y, label=label, linewidth=1.05)
            self.ax.set_title(title)
            self.ax.set_xlabel("Tiempo desde inicio [s]")
            self.ax.set_ylabel(ylabel)
            self.ax.legend(loc="best")
            self._style_axes()
            self.figure.tight_layout()
            self.canvas.draw_idle()
        except Exception as exc:
            messagebox.showerror("Vista rápida", str(exc))
            self.quick_plot.set("Campo individual")

    def export_topic_csv(self) -> None:
        topic = self.topic_combo.get()
        if not topic:
            messagebox.showinfo("CSV", "Selecciona un topic.")
            return
        safe = topic.replace(" ", "_").replace("[", "").replace("]", "")
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            initialdir=str(APP_DIR / "logs"),
            initialfile=f"{safe}.csv",
        )
        if not path:
            return
        try:
            self.ulog.export_topic_csv(topic, path)
            self.progress_text.set(f"CSV exportado: {Path(path).name}")
        except Exception as exc:
            messagebox.showerror("CSV", str(exc))

    # ------------------------------------------------------------------
    # Async / persistence
    # ------------------------------------------------------------------
    def _async(self, fn, on_success=None, on_error=None) -> None:
        def runner():
            try:
                result = fn()
                self.ui_queue.put(("success", on_success, result))
            except Exception as exc:
                self.ui_queue.put(("error", on_error, exc))

        threading.Thread(target=runner, daemon=True).start()

    def _drain_ui_queue(self) -> None:
        try:
            while True:
                kind, cb, payload = self.ui_queue.get_nowait()
                if kind == "call":
                    cb(*payload)
                elif kind == "success":
                    if cb:
                        cb(payload)
                else:
                    if cb:
                        cb(payload)
                    else:
                        self._reset_progress("Operación fallida")
                        messagebox.showerror("Error", str(payload))
        except queue.Empty:
            pass
        self.after(100, self._drain_ui_queue)

    def _progress(self, value: int, total: int, text: str = "") -> None:
        def update():
            self.progress["maximum"] = max(1, total)
            self.progress["value"] = min(value, max(1, total))
            self.progress_text.set(text or f"{value}/{total}")

        self.ui_queue.put(("call", update, ()))

    def _reset_progress(self, text: str = "Listo") -> None:
        self.progress["value"] = 0
        self.progress["maximum"] = 1
        self.progress_text.set(text)

    def _periodic_refresh(self) -> None:
        if not self.client.connected:
            try:
                self._refresh_connection_profiles()
            except Exception:
                pass
        try:
            self.refresh_param_files(force=False)
        except Exception:
            pass
        self.after(3000, self._periodic_refresh)

    def _on_tab_changed(self, _event=None) -> None:
        try:
            index = self.notebook.index(self.notebook.select())
        except tk.TclError:
            return
        if index == 1 and self.client.connected and not self.log_entries and not self.logs_loading:
            self.after(150, self.refresh_logs)

    def _load_settings(self) -> dict:
        try:
            return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def _save_settings(self) -> None:
        data = {
            "param_folder": self.param_folder.get(),
            "connection_profile": self.selected_profile_key,
        }
        try:
            SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _on_close(self) -> None:
        self.cancel_download.set()
        self._save_settings()
        self.client.close()
        self.bridge.stop()
        self.destroy()


if __name__ == "__main__":
    PX4TestTool().mainloop()
