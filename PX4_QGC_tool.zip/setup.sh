#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

PYTHON_VERSION="3.12"
RUNTIME_DIR="$APP_DIR/.runtime"
UV_BIN_DIR="$RUNTIME_DIR/uv-bin"
UV_BIN="$UV_BIN_DIR/uv"
UV_CACHE_DIR="$RUNTIME_DIR/uv-cache"
UV_PYTHON_INSTALL_DIR="$RUNTIME_DIR/python"
UV_PYTHON_BIN_DIR="$RUNTIME_DIR/python-bin"
VENV_DIR="$APP_DIR/.venv"
STAMP_FILE="$VENV_DIR/.px4_qgc_requirements.sha256"

export UV_CACHE_DIR
export UV_PYTHON_INSTALL_DIR
export UV_PYTHON_BIN_DIR
export UV_NO_MODIFY_PATH=1

info() { printf '\033[1;34m[PX4 QGC Tool]\033[0m %s\n' "$*"; }
error() { printf '\033[1;31m[ERROR]\033[0m %s\n' "$*" >&2; }

if [[ "$(uname -s)" != "Linux" ]]; then
    error "Este instalador local está preparado para Linux. Sistema detectado: $(uname -s)."
    exit 1
fi

case "$(uname -m)" in
    x86_64|amd64|aarch64|arm64) ;;
    *)
        error "Arquitectura no probada: $(uname -m)."
        error "El código puede funcionar, pero este bootstrap no se ha validado en esa arquitectura."
        exit 1
        ;;
esac

mkdir -p "$UV_BIN_DIR" "$UV_CACHE_DIR" "$UV_PYTHON_INSTALL_DIR" "$UV_PYTHON_BIN_DIR"

if [[ ! -x "$UV_BIN" ]]; then
    info "Primera configuración: descargando el gestor local 'uv' dentro del proyecto..."
    if command -v curl >/dev/null 2>&1; then
        curl -LsSf https://astral.sh/uv/install.sh | env \
            UV_UNMANAGED_INSTALL="$UV_BIN_DIR" \
            UV_NO_MODIFY_PATH=1 \
            sh
    elif command -v wget >/dev/null 2>&1; then
        wget -qO- https://astral.sh/uv/install.sh | env \
            UV_UNMANAGED_INSTALL="$UV_BIN_DIR" \
            UV_NO_MODIFY_PATH=1 \
            sh
    else
        error "No encuentro curl ni wget para descargar el runtime local."
        error "Instala uno de ellos o prepara el paquete en otro equipo con acceso a Internet."
        exit 1
    fi
fi

if [[ ! -x "$UV_BIN" ]]; then
    error "No se pudo preparar uv en $UV_BIN"
    exit 1
fi

if [[ ! -x "$VENV_DIR/bin/python" ]]; then
    info "Creando un entorno Python $PYTHON_VERSION completamente local..."
    rm -rf "$VENV_DIR"
    "$UV_BIN" venv --python "$PYTHON_VERSION" --managed-python "$VENV_DIR"
fi

if command -v sha256sum >/dev/null 2>&1; then
    REQ_HASH="$(sha256sum requirements.txt | awk '{print $1}')"
else
    # Fallback muy poco habitual en Linux.
    REQ_HASH="force-install"
fi

CURRENT_HASH=""
if [[ -f "$STAMP_FILE" ]]; then
    CURRENT_HASH="$(cat "$STAMP_FILE" 2>/dev/null || true)"
fi

if [[ "$REQ_HASH" != "$CURRENT_HASH" ]]; then
    info "Instalando/actualizando dependencias dentro de .venv..."
    "$UV_BIN" pip install --python "$VENV_DIR/bin/python" -r requirements.txt
    printf '%s\n' "$REQ_HASH" > "$STAMP_FILE"
else
    info "Dependencias ya preparadas; no es necesario reinstalar nada."
fi

info "Comprobando módulos principales..."
"$VENV_DIR/bin/python" - <<'PY'
import tkinter
import numpy
import matplotlib
import serial
import pymavlink
import pyulog
print("OK: entorno aislado listo")
PY

info "Configuración terminada."
info "A partir de ahora abre la aplicación con: ./run.sh"
