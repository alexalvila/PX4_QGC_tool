#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
printf 'Esto eliminará únicamente .venv y .runtime dentro de:\n  %s\n' "$APP_DIR"
read -r -p "¿Continuar? [s/N] " answer
case "$answer" in
    s|S|si|SI|sí|Sí)
        rm -rf "$APP_DIR/.venv" "$APP_DIR/.runtime"
        echo "Entorno local eliminado. No se ha desinstalado ni modificado nada del sistema."
        ;;
    *)
        echo "Cancelado."
        ;;
esac
