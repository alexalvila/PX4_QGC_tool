from __future__ import annotations

import math
import os
import re
import socket
import struct
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Tuple

from pymavlink import mavutil


@dataclass(frozen=True)
class ParamRecord:
    vehicle_id: int
    component_id: int
    name: str
    value: float | int
    mav_type: int


@dataclass(frozen=True)
class LogEntry:
    log_id: int
    time_utc: int
    size: int

    @property
    def date_text(self) -> str:
        if not self.time_utc:
            return "sin fecha"
        try:
            return datetime.fromtimestamp(self.time_utc, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except (OverflowError, OSError, ValueError):
            return str(self.time_utc)


class MavrosQgcBridge:
    """Small local UDP bridge for MAVROS + QGroundControl + this tool.

    Intended topology (localhost only):

      MAVROS gcs_url -> 127.0.0.1:14551 (this bridge)
      bridge -> QGC 127.0.0.1:14550
      bridge -> PX4 tool 127.0.0.1:14552

    MAVROS uses local port 14555 by default for ``udp://@127.0.0.1:14551``.
    Messages from QGC/tool are sent back to MAVROS. The bridge is deliberately
    localhost-only so it does not expose a network service on the LAN.
    """

    def __init__(
        self,
        bridge_port: int = 14551,
        qgc_port: int = 14550,
        tool_port: int = 14552,
        mavros_port: int = 14555,
    ) -> None:
        self.bridge_port = bridge_port
        self.qgc_port = qgc_port
        self.tool_port = tool_port
        self.mavros_port = mavros_port
        self._sock: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.last_mavros_rx = 0.0
        self.rx_packets = 0
        self.tx_packets = 0

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        self.stop()
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(0.25)
        try:
            sock.bind(("127.0.0.1", self.bridge_port))
        except OSError as exc:
            sock.close()
            raise RuntimeError(
                f"No se puede abrir UDP {self.bridge_port} para el puente MAVROS. "
                "Comprueba que no esté ocupado por otro proceso."
            ) from exc
        self._sock = sock
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="mavros-qgc-bridge", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._sock is not None:
            try:
                self._sock.close()
            except OSError:
                pass
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=0.6)
        self._sock = None
        self._thread = None

    def _send(self, data: bytes, port: int) -> None:
        if self._sock is None:
            return
        try:
            self._sock.sendto(data, ("127.0.0.1", port))
            self.tx_packets += 1
        except OSError:
            pass

    def _run(self) -> None:
        while not self._stop.is_set():
            sock = self._sock
            if sock is None:
                return
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                return
            if not data:
                continue

            self.rx_packets += 1
            src_host, src_port = addr[0], int(addr[1])
            if src_host not in {"127.0.0.1", "::1"}:
                continue

            if src_port == self.mavros_port:
                # FCU traffic arriving through MAVROS: duplicate to QGC and the tool.
                self.last_mavros_rx = time.monotonic()
                self._send(data, self.qgc_port)
                self._send(data, self.tool_port)
            elif src_port == self.tool_port or src_port == self.qgc_port:
                # Commands/heartbeats from either GCS go back to MAVROS.
                self._send(data, self.mavros_port)
            else:
                # QGC can use a non-standard source port for a manually-created link.
                # Treat unknown localhost peers as GCS traffic, but never mirror them to the tool.
                self._send(data, self.mavros_port)


def _param_name(raw) -> str:
    if isinstance(raw, bytes):
        return raw.split(b"\x00", 1)[0].decode("ascii", errors="replace")
    return str(raw).split("\x00", 1)[0]


def decode_px4_param(param_value: float, mav_type: int) -> float | int:
    """Decode classic MAVLink PARAM_VALUE using PX4 byte-wise encoding."""
    if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
        return struct.unpack(">i", struct.pack(">f", float(param_value)))[0]
    if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_REAL32:
        return float(param_value)
    return float(param_value)


def encode_px4_param(value: float | int, mav_type: int) -> float:
    """Encode a PX4 parameter into PARAM_SET.param_value."""
    if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
        return struct.unpack(">f", struct.pack(">i", int(value)))[0]
    if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_REAL32:
        return float(value)
    raise ValueError(f"Tipo MAV_PARAM_TYPE no soportado para PX4: {mav_type}")


def parse_qgc_params(path: str | os.PathLike) -> List[ParamRecord]:
    """Read a QGroundControl .params file.

    QGC writes five whitespace/tab-separated columns. Commas are accepted as a
    convenience for files exported through spreadsheets.
    """
    records: List[ParamRecord] = []
    with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
        for line_no, line in enumerate(handle, 1):
            stripped = line.split("#", 1)[0].strip()
            if not stripped:
                continue
            parts = stripped.replace(",", " ").split()
            if len(parts) < 5:
                raise ValueError(f"Línea {line_no}: se esperaban 5 columnas y se obtuvo: {stripped}")
            vehicle_id, component_id, name, value_text, mav_type_text = parts[:5]
            try:
                mav_type = int(mav_type_text)
                if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
                    value: float | int = int(float(value_text))
                else:
                    value = float(value_text)
                records.append(
                    ParamRecord(
                        vehicle_id=int(vehicle_id),
                        component_id=int(component_id),
                        name=name,
                        value=value,
                        mav_type=mav_type,
                    )
                )
            except ValueError as exc:
                raise ValueError(f"Línea {line_no}: formato de parámetro inválido: {stripped}") from exc
    if not records:
        raise ValueError(f"El archivo no contiene parámetros válidos: {Path(path).name}")
    return records


def save_qgc_params(path: str | os.PathLike, params: Iterable[ParamRecord], version_hint: str = "PX4") -> None:
    rows = sorted(params, key=lambda p: (p.component_id, p.name))
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("# Onboard parameters exported by PX4 Flight Lab\n")
        handle.write("#\n")
        handle.write(f"# Stack: {version_hint}\n")
        handle.write("#\n")
        handle.write("# Vehicle-Id Component-Id Name Value Type\n")
        for p in rows:
            if p.mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
                value_text = str(int(p.value))
            else:
                value_text = f"{float(p.value):.17g}"
            handle.write(f"{p.vehicle_id}\t{p.component_id}\t{p.name}\t{value_text}\t{p.mav_type}\n")


def update_qgc_param_value(path: str | os.PathLike, record: ParamRecord) -> None:
    """Update one parameter value in-place while preserving the .params file layout.

    Only the value token is replaced; comments, ordering, separators and the rest of
    the file are left untouched. This is used by the editable preview in the UI.
    """
    path = Path(path)
    raw = path.read_bytes()
    has_bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig", errors="strict")
    lines = text.splitlines(keepends=True)

    if record.mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
        value_text = str(int(record.value))
    else:
        value_text = f"{float(record.value):.17g}"

    found = False
    token_re = re.compile(r"[^,\s]+")
    for idx, line in enumerate(lines):
        code = line.split("#", 1)[0]
        tokens = list(token_re.finditer(code))
        if len(tokens) < 5:
            continue
        try:
            vehicle_id = int(tokens[0].group(0))
            component_id = int(tokens[1].group(0))
        except ValueError:
            continue
        if (
            vehicle_id != record.vehicle_id
            or component_id != record.component_id
            or tokens[2].group(0) != record.name
        ):
            continue

        value_token = tokens[3]
        lines[idx] = line[: value_token.start()] + value_text + line[value_token.end() :]
        found = True
        break

    if not found:
        raise ValueError(f"No se encontró {record.name} en {path.name} para guardar el nuevo valor.")

    new_raw = "".join(lines).encode("utf-8")
    if has_bom:
        new_raw = b"\xef\xbb\xbf" + new_raw

    tmp = path.with_name(path.name + ".edit_tmp")
    try:
        tmp.write_bytes(new_raw)
        try:
            os.chmod(tmp, path.stat().st_mode & 0o7777)
        except OSError:
            pass
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink()
        except FileNotFoundError:
            pass


class MavlinkClient:
    """Small synchronous MAVLink client. Long operations belong in a worker thread."""

    def __init__(self) -> None:
        self.master = None
        self.target_system = 0
        self.target_component = 0
        self._op_lock = threading.RLock()
        self._last_heartbeat = None
        self.endpoint = ""
        self.transport = "unknown"
        self.baud = 0

    @property
    def connected(self) -> bool:
        return self.master is not None and self.target_system != 0

    def connect(self, endpoint: str, baud: int = 115200, timeout: float = 10.0) -> Tuple[int, int]:
        with self._op_lock:
            self.close()
            endpoint = endpoint.strip()
            self.endpoint = endpoint
            self.baud = baud
            kwargs = dict(source_system=254, source_component=190)

            try:
                if endpoint.startswith("serial:"):
                    body = endpoint[len("serial:"):]
                    port = body
                    local_baud = baud
                    if ":" in body:
                        maybe_port, maybe_baud = body.rsplit(":", 1)
                        if maybe_baud.isdigit():
                            port, local_baud = maybe_port, int(maybe_baud)
                    if not Path(port).exists():
                        raise RuntimeError(f"No existe el puerto serie {port}.")
                    self.transport = "radio" if "ttyUSB" in port else "usb"
                    self.baud = local_baud
                    self.master = mavutil.mavlink_connection(
                        port,
                        baud=local_baud,
                        autoreconnect=False,
                        **kwargs,
                    )
                else:
                    self.transport = "udp" if endpoint.startswith("udp") else "network"
                    self.master = mavutil.mavlink_connection(endpoint, baud=baud, autoreconnect=True, **kwargs)
            except Exception as exc:
                self.close()
                msg = str(exc)
                if endpoint.startswith("serial:"):
                    if "Permission" in msg or "permission" in msg:
                        raise RuntimeError(
                            "Sin permiso para abrir el puerto serie. Comprueba que tu usuario puede acceder "
                            "a /dev/ttyACM* o /dev/ttyUSB*."
                        ) from exc
                    if "busy" in msg.lower() or "resource" in msg.lower():
                        raise RuntimeError(
                            "El puerto serie está ocupado. Cierra MAVROS/QGroundControl si están usando "
                            "directamente ese mismo puerto."
                        ) from exc
                raise RuntimeError(f"No se pudo abrir la conexión MAVLink: {exc}") from exc

            deadline = time.monotonic() + timeout
            heartbeat = None
            while time.monotonic() < deadline:
                msg = self.master.recv_match(type="HEARTBEAT", blocking=True, timeout=0.5)
                if msg is None:
                    continue
                if getattr(msg, "type", None) == mavutil.mavlink.MAV_TYPE_GCS:
                    continue
                heartbeat = msg
                break
            if heartbeat is None:
                current_endpoint = self.endpoint
                current_transport = self.transport
                self.close()
                if current_transport == "radio":
                    raise TimeoutError(
                        "No se recibió HEARTBEAT por la radio. Verifica que /dev/ttyUSB* corresponde a la "
                        "radio, que trabaja a 57600 baud y que MAVROS/QGC no tienen abierto ese puerto."
                    )
                if current_transport == "udp":
                    raise TimeoutError(
                        "No se recibió HEARTBEAT por UDP. Si QGroundControl ya usa el puerto 14550, elige "
                        "el perfil 'MAVROS + QGroundControl' y usa gcs_url con puerto 14551."
                    )
                raise TimeoutError(f"No se recibió HEARTBEAT del autopiloto en {current_endpoint}.")

            self.target_system = heartbeat.get_srcSystem()
            self.target_component = heartbeat.get_srcComponent()
            self.master.target_system = self.target_system
            self.master.target_component = self.target_component
            self._last_heartbeat = heartbeat
            return self.target_system, self.target_component

    def close(self) -> None:
        if self.master is not None:
            try:
                self.master.close()
            except Exception:
                pass
        self.master = None
        self.target_system = 0
        self.target_component = 0
        self._last_heartbeat = None
        self.endpoint = ""
        self.transport = "unknown"
        self.baud = 0

    def _require_connection(self):
        if not self.connected:
            raise RuntimeError("No hay conexión MAVLink activa.")
        return self.master

    def is_armed(self, timeout: float = 1.2) -> Optional[bool]:
        with self._op_lock:
            master = self._require_connection()
            msg = master.recv_match(type="HEARTBEAT", blocking=True, timeout=timeout)
            if msg is not None and msg.get_srcSystem() == self.target_system:
                self._last_heartbeat = msg
            else:
                msg = self._last_heartbeat
            if msg is None:
                return None
            return bool(msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)

    def request_all_params(
        self,
        timeout: float = 24.0,
        progress: Optional[Callable[[int, int], None]] = None,
    ) -> Dict[Tuple[int, str], ParamRecord]:
        with self._op_lock:
            master = self._require_connection()
            while master.recv_match(type="PARAM_VALUE", blocking=False) is not None:
                pass

            master.mav.param_request_list_send(self.target_system, self.target_component)
            params: Dict[Tuple[int, str], ParamRecord] = {}
            indices_by_component: Dict[int, set[int]] = {}
            expected_by_component: Dict[int, int] = {}
            last_new = time.monotonic()
            started = time.monotonic()
            last_retry = started

            while time.monotonic() - started < timeout:
                msg = master.recv_match(type=["PARAM_VALUE", "PARAM_ERROR"], blocking=True, timeout=0.35)
                now = time.monotonic()
                if msg is None:
                    # On lossy radio links, re-ask for the list if progress has stalled.
                    if params and now - last_new > 2.5 and now - last_retry > 2.5:
                        master.mav.param_request_list_send(self.target_system, self.target_component)
                        last_retry = now
                    if params and now - last_new > 6.0:
                        break
                    continue
                if msg.get_type() == "PARAM_ERROR" or msg.get_srcSystem() != self.target_system:
                    continue

                name = _param_name(msg.param_id)
                comp = msg.get_srcComponent()
                count = int(msg.param_count)
                index = int(msg.param_index)
                if index >= count or name in {"_HASH_CHECK", "PARAM_HASH"}:
                    continue

                value = decode_px4_param(msg.param_value, int(msg.param_type))
                key = (comp, name)
                if key not in params:
                    last_new = now
                params[key] = ParamRecord(
                    vehicle_id=self.target_system,
                    component_id=comp,
                    name=name,
                    value=value,
                    mav_type=int(msg.param_type),
                )
                expected_by_component[comp] = count
                indices_by_component.setdefault(comp, set()).add(index)

                got = sum(len(v) for v in indices_by_component.values())
                expected = sum(expected_by_component.values())
                if progress:
                    progress(got, expected)
                if expected > 0 and got >= expected:
                    break

            if not params:
                raise TimeoutError("No se recibieron parámetros del vehículo.")
            return params

    @staticmethod
    def _same_value(a: float | int, b: float | int, mav_type: int) -> bool:
        if mav_type == mavutil.mavlink.MAV_PARAM_TYPE_INT32:
            return int(a) == int(b)
        return math.isclose(float(a), float(b), rel_tol=1e-6, abs_tol=1e-6)

    def set_param(self, record: ParamRecord, retries: int = 3, ack_timeout: float = 1.5) -> Tuple[bool, str]:
        with self._op_lock:
            master = self._require_connection()
            if record.mav_type not in (
                mavutil.mavlink.MAV_PARAM_TYPE_INT32,
                mavutil.mavlink.MAV_PARAM_TYPE_REAL32,
            ):
                return False, f"tipo {record.mav_type} no soportado por PX4 clásico"

            target_component = record.component_id or self.target_component
            encoded = encode_px4_param(record.value, record.mav_type)
            for _ in range(retries):
                master.mav.param_set_send(
                    self.target_system,
                    target_component,
                    record.name.encode("ascii", errors="ignore")[:16],
                    encoded,
                    record.mav_type,
                )
                deadline = time.monotonic() + ack_timeout
                while time.monotonic() < deadline:
                    msg = master.recv_match(type=["PARAM_VALUE", "PARAM_ERROR"], blocking=True, timeout=0.15)
                    if msg is None or msg.get_srcSystem() != self.target_system:
                        continue
                    if msg.get_type() == "PARAM_ERROR":
                        err_name = _param_name(getattr(msg, "param_id", ""))
                        if not err_name or err_name == record.name:
                            return False, f"PARAM_ERROR={getattr(msg, 'error', 'desconocido')}"
                        continue
                    if _param_name(msg.param_id) != record.name:
                        continue
                    ack_value = decode_px4_param(msg.param_value, int(msg.param_type))
                    if self._same_value(ack_value, record.value, record.mav_type):
                        return True, "ok"
                    return False, f"ACK distinto: {ack_value}"
            return False, "timeout esperando PARAM_VALUE"

    def apply_param_file(
        self,
        path: str | os.PathLike,
        changed_only: bool = True,
        progress: Optional[Callable[[int, int, str], None]] = None,
    ) -> List[Tuple[ParamRecord, bool, str]]:
        if self.is_armed() is True:
            raise RuntimeError("El vehículo está armado. Se cancela la carga de parámetros.")

        records = parse_qgc_params(path)
        current: Dict[Tuple[int, str], ParamRecord] = {}
        if changed_only:
            current = self.request_all_params(timeout=30.0 if self.transport == "radio" else 22.0)

        todo: List[ParamRecord] = []
        for rec in records:
            key = (rec.component_id, rec.name)
            old = current.get(key)
            if changed_only and old is not None and self._same_value(old.value, rec.value, rec.mav_type):
                continue
            todo.append(rec)

        results: List[Tuple[ParamRecord, bool, str]] = []
        total = len(todo)
        for idx, rec in enumerate(todo, 1):
            ok, reason = self.set_param(rec, ack_timeout=2.2 if self.transport == "radio" else 1.5)
            results.append((rec, ok, reason))
            if progress:
                progress(idx, total, rec.name)
            if not ok:
                time.sleep(0.03)
        return results

    def list_logs(self, timeout: float = 10.0) -> List[LogEntry]:
        """Return onboard logs, retrying the list request on lossy links."""
        with self._op_lock:
            master = self._require_connection()
            while master.recv_match(type="LOG_ENTRY", blocking=False) is not None:
                pass

            entries: Dict[int, LogEntry] = {}
            expected: int | None = None
            started = time.monotonic()
            last_new = started
            last_request = 0.0

            while time.monotonic() - started < timeout:
                now = time.monotonic()
                if last_request == 0.0 or (now - last_new > 1.4 and now - last_request > 1.4):
                    master.mav.log_request_list_send(self.target_system, self.target_component, 0, 0xFFFF)
                    last_request = now

                msg = master.recv_match(type="LOG_ENTRY", blocking=True, timeout=0.35)
                if msg is None:
                    if entries and expected is not None and len(entries) >= expected:
                        break
                    if entries and time.monotonic() - last_new > 3.5:
                        break
                    continue
                if msg.get_srcSystem() != self.target_system:
                    continue
                if int(msg.num_logs) == 0:
                    break

                entry = LogEntry(int(msg.id), int(msg.time_utc), int(msg.size))
                if entry.log_id not in entries:
                    last_new = time.monotonic()
                entries[entry.log_id] = entry
                expected = int(msg.num_logs)
                if expected and len(entries) >= expected:
                    break

            try:
                master.mav.log_request_end_send(self.target_system, self.target_component)
            except Exception:
                pass
            return sorted(entries.values(), key=lambda e: e.log_id, reverse=True)

    @staticmethod
    def _missing_runs(missing_indices: List[int], chunk_size: int, total_size: int, max_bytes: int) -> List[Tuple[int, int]]:
        if not missing_indices:
            return []
        runs: List[Tuple[int, int]] = []
        start = prev = missing_indices[0]
        max_chunks = max(1, max_bytes // chunk_size)
        for idx in missing_indices[1:]:
            if idx == prev + 1 and (idx - start + 1) <= max_chunks:
                prev = idx
                continue
            ofs = start * chunk_size
            end = min(total_size, (prev + 1) * chunk_size)
            runs.append((ofs, end - ofs))
            start = prev = idx
        ofs = start * chunk_size
        end = min(total_size, (prev + 1) * chunk_size)
        runs.append((ofs, end - ofs))
        return runs

    def download_log(
        self,
        entry: LogEntry,
        destination: str | os.PathLike,
        progress: Optional[Callable[[int, int], None]] = None,
        cancel_event: Optional[threading.Event] = None,
    ) -> Path:
        """Download an onboard ULog using small, retryable LOG_DATA windows.

        PX4 links can silently drop a large burst of LOG_DATA packets even on USB.
        Keeping each request bounded makes the transfer slower only marginally but
        prevents a single oversized request from losing thousands of 90-byte blocks.
        Incomplete ``.part`` files are removed on failure or cancellation.
        """
        with self._op_lock:
            master = self._require_connection()
            destination = Path(destination)
            destination.parent.mkdir(parents=True, exist_ok=True)
            tmp = destination.with_suffix(destination.suffix + ".part")
            chunk_size = 90

            # Conservative windows are intentional. A 500+ KiB request can overflow
            # queues on some Pixhawk/USB combinations and then every block appears lost.
            if self.transport == "radio":
                window_chunks = 64       # 5.6 KiB per request
                retry_chunks = 24
                idle_timeout = 0.75
                response_timeout = 3.8
                max_attempts = 10
            elif self.transport == "usb":
                window_chunks = 256      # 22.5 KiB per request
                retry_chunks = 64
                idle_timeout = 0.55
                response_timeout = 3.0
                max_attempts = 8
            else:
                window_chunks = 512      # 45 KiB per request
                retry_chunks = 128
                idle_timeout = 0.55
                response_timeout = 3.0
                max_attempts = 8

            if entry.size <= 0:
                raise ValueError(f"El log {entry.log_id} tiene tamaño cero y no se puede descargar.")

            chunk_count = (entry.size + chunk_size - 1) // chunk_size
            received = bytearray(chunk_count)
            total_received = 0

            # A previous interrupted transfer must never be mistaken for a valid .ulg.
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass

            # Discard delayed data from an older transfer before requesting this log.
            while master.recv_match(type="LOG_DATA", blocking=False) is not None:
                pass

            with open(tmp, "wb") as handle:
                handle.truncate(entry.size)

            def expected_chunk_bytes(index: int) -> int:
                return min(chunk_size, entry.size - index * chunk_size)

            def collect(handle, deadline: float, first_idx: int, last_idx: int) -> bool:
                nonlocal total_received
                got_any = False
                last_packet = time.monotonic()
                while time.monotonic() < deadline:
                    if cancel_event and cancel_event.is_set():
                        raise RuntimeError("Descarga cancelada por el usuario.")
                    if all(received[i] for i in range(first_idx, last_idx + 1)):
                        return got_any

                    timeout = min(0.20, max(0.01, deadline - time.monotonic()))
                    msg = master.recv_match(type="LOG_DATA", blocking=True, timeout=timeout)
                    if msg is None:
                        if got_any and time.monotonic() - last_packet >= idle_timeout:
                            break
                        continue
                    if msg.get_srcSystem() != self.target_system or int(msg.id) != entry.log_id:
                        continue

                    count = int(msg.count)
                    ofs = int(msg.ofs)
                    if count <= 0 or ofs < 0 or ofs >= entry.size:
                        continue

                    payload = bytes(msg.data[: min(count, entry.size - ofs)])
                    if not payload:
                        continue
                    handle.seek(ofs)
                    handle.write(payload)
                    got_any = True
                    last_packet = time.monotonic()

                    # PX4 LOG_DATA packets are 90-byte aligned except for the final one.
                    # Mark only fully covered chunks, so a truncated packet is retried.
                    first = ofs // chunk_size
                    last = (ofs + len(payload) - 1) // chunk_size
                    for idx in range(first, min(last, chunk_count - 1) + 1):
                        chunk_start = idx * chunk_size
                        chunk_end = min(entry.size, chunk_start + chunk_size)
                        payload_start = ofs
                        payload_end = ofs + len(payload)
                        if payload_start <= chunk_start and payload_end >= chunk_end and not received[idx]:
                            received[idx] = 1
                            total_received += expected_chunk_bytes(idx)
                            if progress:
                                progress(min(total_received, entry.size), entry.size)
                return got_any

            try:
                with open(tmp, "r+b", buffering=0) as handle:
                    first_idx = 0
                    while first_idx < chunk_count:
                        if cancel_event and cancel_event.is_set():
                            raise RuntimeError("Descarga cancelada por el usuario.")

                        last_idx = min(chunk_count - 1, first_idx + window_chunks - 1)
                        attempts = 0
                        while attempts < max_attempts:
                            missing = [i for i in range(first_idx, last_idx + 1) if not received[i]]
                            if not missing:
                                break
                            attempts += 1

                            max_run_chunks = window_chunks if attempts == 1 else retry_chunks
                            runs = self._missing_runs(
                                missing,
                                chunk_size,
                                entry.size,
                                max_run_chunks * chunk_size,
                            )

                            for req_start, req_count in runs:
                                if cancel_event and cancel_event.is_set():
                                    raise RuntimeError("Descarga cancelada por el usuario.")
                                req_first = req_start // chunk_size
                                req_last = min(
                                    chunk_count - 1,
                                    (req_start + req_count - 1) // chunk_size,
                                )
                                master.mav.log_request_data_send(
                                    self.target_system,
                                    self.target_component,
                                    entry.log_id,
                                    int(req_start),
                                    int(req_count),
                                )
                                collect(
                                    handle,
                                    time.monotonic() + response_timeout,
                                    req_first,
                                    req_last,
                                )

                            if all(received[i] for i in range(first_idx, last_idx + 1)):
                                break
                            # Give the FCU/serial buffers a brief chance to drain before retrying.
                            time.sleep(0.025 if self.transport != "radio" else 0.06)

                        missing = [i for i in range(first_idx, last_idx + 1) if not received[i]]
                        if missing:
                            first_missing = missing[0] * chunk_size
                            raise TimeoutError(
                                f"La descarga no pudo recuperar {len(missing)} bloques del log {entry.log_id} "
                                f"cerca del offset {first_missing}. Reintenta con un enlace de telemetría estable."
                            )
                        first_idx = last_idx + 1

                if total_received != entry.size:
                    raise TimeoutError(f"Descarga incompleta: {total_received}/{entry.size} bytes recibidos.")

                # A valid PX4 ULog starts with the seven-byte ULog magic sequence.
                with open(tmp, "rb") as handle:
                    if handle.read(7) != b"ULog\x01\x12\x35":
                        raise RuntimeError("El archivo recibido no tiene una cabecera ULog válida.")

                tmp.replace(destination)
                return destination
            except Exception:
                try:
                    tmp.unlink()
                except FileNotFoundError:
                    pass
                raise
            finally:
                try:
                    master.mav.log_request_end_send(self.target_system, self.target_component)
                except Exception:
                    pass
