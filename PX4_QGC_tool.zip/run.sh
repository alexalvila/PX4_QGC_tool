#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

VENV_PYTHON="$APP_DIR/.venv/bin/python"

# Si es la primera ejecución (o se borró el entorno), lo prepara automáticamente.
if [[ ! -x "$VENV_PYTHON" ]]; then
    echo "[PX4 QGC Tool] No existe todavía el entorno local. Ejecutando configuración inicial..."
    "$APP_DIR/setup.sh"
fi

exec "$VENV_PYTHON" "$APP_DIR/app.py"
