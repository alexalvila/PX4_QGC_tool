from __future__ import annotations

import csv
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from pyulog import ULog


@dataclass(frozen=True)
class TopicRef:
    name: str
    multi_id: int

    @property
    def label(self) -> str:
        return f"{self.name} [{self.multi_id}]"


class ULogModel:
    def __init__(self) -> None:
        self.path: Path | None = None
        self.ulog: ULog | None = None
        self._topics: Dict[str, object] = {}

    def load(self, path: str | Path) -> None:
        self.path = Path(path)
        self.ulog = ULog(str(path))
        self._topics = {f"{d.name} [{d.multi_id}]": d for d in self.ulog.data_list}

    def topics(self) -> List[str]:
        return sorted(self._topics.keys())

    def fields(self, topic_label: str) -> List[str]:
        dataset = self._topics[topic_label]
        out: List[str] = []
        for key, values in dataset.data.items():
            if key == "timestamp" or key.startswith("_padding"):
                continue
            arr = np.asarray(values)
            if arr.ndim == 1:
                if np.issubdtype(arr.dtype, np.number):
                    out.append(key)
            elif arr.ndim == 2 and np.issubdtype(arr.dtype, np.number):
                for idx in range(arr.shape[1]):
                    out.append(f"{key}[{idx}]")
        return sorted(out)

    @staticmethod
    def _split_field(field: str) -> Tuple[str, int | None]:
        m = re.fullmatch(r"(.+)\[(\d+)\]", field)
        if m:
            return m.group(1), int(m.group(2))
        return field, None

    def series(self, topic_label: str, field: str):
        dataset = self._topics[topic_label]
        base, index = self._split_field(field)
        t = np.asarray(dataset.data["timestamp"], dtype=np.float64) / 1e6
        t = t - t[0] if len(t) else t
        y = np.asarray(dataset.data[base])
        if index is not None:
            y = y[:, index]
        return t, y

    def _dataset(self, topic_name: str, multi_id: int = 0):
        label = f"{topic_name} [{multi_id}]"
        return self._topics.get(label)

    @staticmethod
    def _time(dataset):
        t = np.asarray(dataset.data["timestamp"], dtype=np.float64) / 1e6
        return t - t[0] if len(t) else t

    def quick_plot(self, preset: str):
        """Return (title, y_label, [(label, t, y), ...]) for common PX4 plots."""
        if preset == "Actitud":
            d = self._dataset("vehicle_attitude")
            if d is None:
                raise KeyError("El ULog no contiene vehicle_attitude.")
            t = self._time(d)
            q0 = np.asarray(d.data["q[0]"], dtype=float)
            q1 = np.asarray(d.data["q[1]"], dtype=float)
            q2 = np.asarray(d.data["q[2]"], dtype=float)
            q3 = np.asarray(d.data["q[3]"], dtype=float)
            sinr_cosp = 2.0 * (q0 * q1 + q2 * q3)
            cosr_cosp = 1.0 - 2.0 * (q1 * q1 + q2 * q2)
            roll = np.degrees(np.arctan2(sinr_cosp, cosr_cosp))
            sinp = np.clip(2.0 * (q0 * q2 - q3 * q1), -1.0, 1.0)
            pitch = np.degrees(np.arcsin(sinp))
            siny_cosp = 2.0 * (q0 * q3 + q1 * q2)
            cosy_cosp = 1.0 - 2.0 * (q2 * q2 + q3 * q3)
            yaw = np.degrees(np.arctan2(siny_cosp, cosy_cosp))
            return "Actitud del vehículo", "Ángulo [°]", [("Roll", t, roll), ("Pitch", t, pitch), ("Yaw", t, yaw)]

        if preset == "Velocidad angular":
            d = self._dataset("vehicle_angular_velocity")
            if d is None:
                raise KeyError("El ULog no contiene vehicle_angular_velocity.")
            t = self._time(d)
            values = []
            for label, key in (("X", "xyz[0]"), ("Y", "xyz[1]"), ("Z", "xyz[2]")):
                values.append((label, t, np.degrees(np.asarray(d.data[key], dtype=float))))
            return "Velocidad angular", "Velocidad [°/s]", values

        if preset == "Posición local":
            d = self._dataset("vehicle_local_position")
            if d is None:
                raise KeyError("El ULog no contiene vehicle_local_position.")
            t = self._time(d)
            return (
                "Posición local NED",
                "Posición [m]",
                [("X", t, np.asarray(d.data["x"])), ("Y", t, np.asarray(d.data["y"])), ("Z", t, np.asarray(d.data["z"]))],
            )

        if preset == "Velocidad local":
            d = self._dataset("vehicle_local_position")
            if d is None:
                raise KeyError("El ULog no contiene vehicle_local_position.")
            t = self._time(d)
            return (
                "Velocidad local NED",
                "Velocidad [m/s]",
                [("Vx", t, np.asarray(d.data["vx"])), ("Vy", t, np.asarray(d.data["vy"])), ("Vz", t, np.asarray(d.data["vz"]))],
            )

        if preset == "Batería":
            d = self._dataset("battery_status")
            if d is None:
                raise KeyError("El ULog no contiene battery_status.")
            t = self._time(d)
            voltage_key = "voltage_filtered_v" if "voltage_filtered_v" in d.data else "voltage_v"
            return (
                "Batería",
                "Valor",
                [
                    ("Voltaje [V]", t, np.asarray(d.data[voltage_key], dtype=float)),
                    ("Corriente [A]", t, np.asarray(d.data["current_a"], dtype=float)),
                ],
            )

        if preset == "Comunicación":
            # Prefer the radio link metrics because they are immediately useful for
            # diagnosing telemetry quality. Fall back to MAVLink telemetry status on
            # vehicles/logs that do not publish radio_status.
            d = self._dataset("radio_status")
            if d is not None:
                t = self._time(d)
                series = []
                for label, key in (
                    ("RSSI local", "rssi"),
                    ("RSSI remoto", "remote_rssi"),
                    ("Ruido local", "noise"),
                    ("Ruido remoto", "remote_noise"),
                ):
                    if key in d.data:
                        series.append((label, t, np.asarray(d.data[key], dtype=float)))
                if series:
                    return "Comunicación · radio", "Nivel de señal / ruido", series

            d = self._dataset("telemetry_status")
            if d is not None:
                t = self._time(d)
                series = []
                if "rx_message_lost_rate" in d.data:
                    series.append(
                        (
                            "Mensajes RX perdidos [%]",
                            t,
                            100.0 * np.asarray(d.data["rx_message_lost_rate"], dtype=float),
                        )
                    )
                if "tx_error_rate_avg" in d.data:
                    series.append(
                        (
                            "Errores TX [%]",
                            t,
                            100.0 * np.asarray(d.data["tx_error_rate_avg"], dtype=float),
                        )
                    )
                if series:
                    return "Comunicación · MAVLink", "Tasa [%]", series

            raise KeyError("El ULog no contiene datos de comunicación (radio_status/telemetry_status).")

        raise KeyError(f"Vista rápida desconocida: {preset}")

    def summary(self) -> dict:
        if self.ulog is None:
            return {}
        return {
            "topics": len(self.ulog.data_list),
            "start_timestamp_us": int(self.ulog.start_timestamp),
            "last_timestamp_us": int(self.ulog.last_timestamp),
            "duration_s": (self.ulog.last_timestamp - self.ulog.start_timestamp) / 1e6,
            "version": self.ulog.get_version_info_str(),
            "dropouts": len(self.ulog.dropouts),
        }

    def export_topic_csv(self, topic_label: str, path: str | Path) -> None:
        dataset = self._topics[topic_label]
        keys = [k for k in dataset.data.keys() if not k.startswith("_padding")]
        columns = []
        names = []
        for key in keys:
            arr = np.asarray(dataset.data[key])
            if arr.ndim == 1:
                names.append(key)
                columns.append(arr)
            elif arr.ndim == 2:
                for idx in range(arr.shape[1]):
                    names.append(f"{key}[{idx}]")
                    columns.append(arr[:, idx])
        with open(path, "w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(names)
            for row in zip(*columns):
                writer.writerow(row)
